from providers.orionoid import Orionoid
if provider == Orionoid.Id:
    max_results = Orionoid.limit()
